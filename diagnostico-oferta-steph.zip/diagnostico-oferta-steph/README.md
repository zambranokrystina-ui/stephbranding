# Diagnóstico de oferta de valor — pasos para publicarlo

Son diez preguntas en cuatro bloques (Negocio, Cliente ideal, Transformación,
Diferenciación) más el nombre. Las respuestas llegan a una hoja nueva, separada
de la encuesta de branding.

## 1. Crear la hoja y el backend

1. Crea una **Hoja de cálculo nueva** en Google Sheets (en tu cuenta de Gmail personal).
2. En el menú: **Extensiones → Apps Script**.
3. Borra lo que haya en el editor y pega todo el contenido de `Codigo.gs`.
4. Guarda (ícono de disquete).
5. Ejecuta una vez la función **prueba** y acepta los permisos.
   Esto crea la pestaña "Diagnostico" y deja una fila de prueba.
6. Revisa la hoja. Luego borra esa fila de prueba.

## 2. Publicar el backend

1. En Apps Script: **Implementar → Nueva implementación**.
2. Tipo: **Aplicación web**.
3. Ejecutar como: **Yo**. Quién tiene acceso: **Cualquier persona**.
4. Copia la URL que termina en `/exec`.

## 3. Conectar la página con el backend

1. Abre `index.html` en un editor de texto.
2. Busca la línea `var ENDPOINT = 'PEGAR_URL_AQUI';`
3. Reemplaza `PEGAR_URL_AQUI` por la URL `/exec` que copiaste. Deja las comillas.

## 4. Publicarla como página

Opciones, de más sencilla a menos:

- **GitHub Pages:** crea una carpeta `diagnostico` en el repositorio, sube `index.html`
  con ese nombre exacto y activa Pages (Settings → Pages → main / root).
- **Netlify Drop:** arrastra la carpeta a app.netlify.com/drop y te da un enlace.

Systeme.io solo puede embeber la página con un iframe. Si la quieres dentro de
Systeme, usa el enlace directo de la página publicada como botón, no el iframe.

## 5. Probar antes de enviarla

- Llena la encuesta completa una vez, desde el celular.
- Revisa que los párrafos largos lleguen completos a la hoja.
- Revisa que llegue el aviso por correo a Gmail.
- Borra las filas de prueba antes de compartirla con Steph.

## Sobre los datos

- Las respuestas quedan en la hoja de Google. Solo tú tienes acceso a ella.
- La URL `/exec` queda dentro del código de la página, así que cualquiera que la
  vea podría enviar datos falsos a la hoja. Para una encuesta de una sola persona
  es un riesgo bajo; si algún día hay muchas personas, conviene revisar la hoja
  antes de tomar decisiones.

Desarrollado por Mercadeo MRR LLC.
