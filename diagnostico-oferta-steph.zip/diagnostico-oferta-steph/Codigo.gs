/**
 * DIAGNÓSTICO DE OFERTA DE VALOR — STEPHANIE
 * Backend de la encuesta interactiva. Escribe en la Hoja de Cálculo.
 * Mentes Abundantes · Desarrollado por Mercadeo MRR LLC
 *
 * Recibe los datos por GET, una respuesta por lote. Todos los lotes traen
 * el mismo "id", y el script completa la MISMA fila en lugar de crear otra.
 */

var CONFIG = {
  HOJA: 'Diagnostico',
  NOTIFICAR: ['zambranokrystina@gmail.com'],
  AVISAR_AL_TERMINAR: true
};

/* Encabezados de la hoja. El script busca cada columna POR NOMBRE,
   así que puedes reordenarlas en la hoja sin romper nada. */
var COLUMNAS = [
  'Fecha', 'ID', 'Nombre',

  // Negocio
  'P1 Qué vendes',
  'P2 Qué quieres vender más',

  // Cliente ideal
  'P3 Quién lo necesita',
  'P4 Problema más importante',
  'P5 Qué desea conseguir',

  // Transformación
  'P6 Qué cambia después',
  'P7 Resultado concreto',

  // Diferenciación
  'P8 Por qué elegirte',
  'P9 Qué haces diferente',
  'P10 Pruebas de que funciona',

  'Completada'
];

/* Qué parámetro de la URL va en qué columna */
var MAPA = {
  nombre: 'Nombre',
  q1:  'P1 Qué vendes',
  q2:  'P2 Qué quieres vender más',
  q3:  'P3 Quién lo necesita',
  q4:  'P4 Problema más importante',
  q5:  'P5 Qué desea conseguir',
  q6:  'P6 Qué cambia después',
  q7:  'P7 Resultado concreto',
  q8:  'P8 Por qué elegirte',
  q9:  'P9 Qué haces diferente',
  q10: 'P10 Pruebas de que funciona'
};

/* ─────────────────────────────────────────────── */

function doGet(e) {
  try {
    var p = (e && e.parameter) ? e.parameter : {};
    var id = String(p.id || '').trim();
    if (!id) return pixel();

    var hoja = obtenerHoja();
    var lock = LockService.getScriptLock();
    lock.waitLock(20000);

    try {
      var enc = encabezados(hoja);
      var fila = buscarFilaPorId(hoja, enc, id);

      if (fila === -1) {
        var vacia = new Array(enc.length).fill('');
        vacia[enc.indexOf('Fecha')] = new Date();
        vacia[enc.indexOf('ID')] = id;
        vacia[enc.indexOf('Completada')] = 'No';
        hoja.appendRow(vacia);
        fila = hoja.getLastRow();
      }

      // Escribe solo las celdas que vinieron en este lote
      for (var clave in MAPA) {
        if (!Object.prototype.hasOwnProperty.call(p, clave)) continue;
        var valor = String(p[clave] || '').trim();
        if (valor === '') continue;
        var col = enc.indexOf(MAPA[clave]) + 1;
        if (col > 0) hoja.getRange(fila, col).setValue(valor);
      }

      // El último lote trae fin=1
      if (String(p.fin || '') === '1') {
        var colC = enc.indexOf('Completada') + 1;
        if (colC > 0) hoja.getRange(fila, colC).setValue('Sí');
        if (CONFIG.AVISAR_AL_TERMINAR) {
          var colN = enc.indexOf('Nombre') + 1;
          var nom = colN > 0 ? hoja.getRange(fila, colN).getValue() : '';
          avisar(nom, id);
        }
      }
    } finally {
      lock.releaseLock();
    }

    return pixel();
  } catch (err) {
    console.error(err);
    return pixel();
  }
}

/* ── Hoja ── */

function obtenerHoja() {
  var libro = SpreadsheetApp.getActiveSpreadsheet();
  var hoja = libro.getSheetByName(CONFIG.HOJA);
  if (!hoja) {
    hoja = libro.insertSheet(CONFIG.HOJA);
  }
  if (hoja.getLastRow() === 0) {
    hoja.appendRow(COLUMNAS);
    var cab = hoja.getRange(1, 1, 1, COLUMNAS.length);
    cab.setFontWeight('bold')
       .setBackground('#4B2E73')
       .setFontColor('#FFFFFF')
       .setVerticalAlignment('middle')
       .setWrap(true);
    hoja.setRowHeight(1, 46);
    hoja.setFrozenRows(1);
    hoja.setFrozenColumns(3);
    for (var i = 1; i <= COLUMNAS.length; i++) hoja.setColumnWidth(i, 260);
    hoja.setColumnWidth(1, 150); // Fecha
    hoja.setColumnWidth(2, 170); // ID
    hoja.setColumnWidth(3, 180); // Nombre
  }
  return hoja;
}

function encabezados(hoja) {
  return hoja.getRange(1, 1, 1, hoja.getLastColumn()).getValues()[0]
             .map(function (v) { return String(v).trim(); });
}

function buscarFilaPorId(hoja, enc, id) {
  var colId = enc.indexOf('ID') + 1;
  if (colId < 1) return -1;
  var n = hoja.getLastRow();
  if (n < 2) return -1;
  var vals = hoja.getRange(2, colId, n - 1, 1).getValues();
  for (var i = 0; i < vals.length; i++) {
    if (String(vals[i][0]).trim() === id) return i + 2;
  }
  return -1;
}

/* ── Aviso por correo ── */

function avisar(nombre, id) {
  try {
    var url = SpreadsheetApp.getActiveSpreadsheet().getUrl();
    var cuerpo =
      (nombre || 'Alguien') + ' completó el diagnóstico de oferta de valor.\n\n' +
      'Abre la hoja para leer las respuestas:\n' + url + '\n\n' +
      'Por dónde empezar a leer:\n' +
      '  1. El cliente ideal: P3, P4 y P5.\n' +
      '  2. El porqué: P8 y P10. Si P10 viene en blanco, es un hallazgo en sí mismo.\n' +
      '  3. Compara P1 con P2: lo que vende hoy contra lo que quiere vender.\n\n' +
      'ID del registro: ' + id;

    MailApp.sendEmail({
      to: CONFIG.NOTIFICAR.join(','),
      subject: '✦ Diagnóstico de oferta completado — ' + (nombre || 'sin nombre'),
      body: cuerpo
    });
  } catch (err) {
    console.error(err);
  }
}

/* ── Respuesta mínima para que el navegador no se quede esperando ── */

function pixel() {
  var gif = Utilities.base64Decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
  return ContentService
    .createTextOutput(Utilities.newBlob(gif, 'image/gif').getDataAsString())
    .setMimeType(ContentService.MimeType.TEXT);
}

/* ── Menú en la hoja ── */

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Diagnóstico')
    .addItem('Preparar la hoja', 'prepararHoja')
    .addItem('Ver resumen', 'verResumen')
    .addSeparator()
    .addItem('Exportar respuestas a CSV', 'exportarCSV')
    .addToUi();
}

function prepararHoja() {
  obtenerHoja();
  SpreadsheetApp.getUi().alert('Hoja lista. Ya puede recibir respuestas.');
}

function verResumen() {
  var hoja = obtenerHoja();
  var enc = encabezados(hoja);
  var n = hoja.getLastRow() - 1;
  if (n < 1) {
    SpreadsheetApp.getUi().alert('Todavía no hay respuestas.');
    return;
  }
  var colC = enc.indexOf('Completada') + 1;
  var completas = 0;
  if (colC > 0) {
    hoja.getRange(2, colC, n, 1).getValues().forEach(function (f) {
      if (String(f[0]) === 'Sí') completas++;
    });
  }
  SpreadsheetApp.getUi().alert(
    'Registros: ' + n + '\nCompletados: ' + completas +
    '\nIncompletos: ' + (n - completas)
  );
}

function exportarCSV() {
  var hoja = obtenerHoja();
  var n = hoja.getLastRow();
  if (n < 2) {
    SpreadsheetApp.getUi().alert('Todavía no hay respuestas.');
    return;
  }
  var datos = hoja.getRange(1, 1, n, hoja.getLastColumn()).getValues();
  var csv = datos.map(function (fila) {
    return fila.map(csvSeguro).join(',');
  }).join('\n');

  var nombre = 'diagnostico-oferta-steph-' +
    Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd-HHmm') + '.csv';
  var archivo = DriveApp.createFile(Utilities.newBlob('﻿' + csv, 'text/csv', nombre));
  SpreadsheetApp.getUi().alert('Listo. El archivo quedó en tu Drive:\n\n' + archivo.getName());
}

function csvSeguro(v) {
  var s = (v === null || v === undefined) ? '' : String(v);
  if (s.indexOf('"') !== -1 || s.indexOf(',') !== -1 || s.indexOf('\n') !== -1) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

/* ── Función de prueba: ejecútala una vez para aceptar los permisos ── */

function prueba() {
  var r = doGet({ parameter: {
    id: 'prueba-' + Date.now(),
    nombre: 'Prueba Mercadeo MRR',
    q1: 'Esta es una fila de prueba. Bórrala cuando confirmes que funciona.',
    q3: 'Prueba',
    fin: '1'
  }});
  Logger.log('Listo. Revisa la hoja "' + CONFIG.HOJA + '".');
  return r;
}
